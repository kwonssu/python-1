# 2019 년 파이썬 빅데이터 / 머신러닝 
* 쥬피터 노트북 스크립트
### 목록
- 서울의 100년간의 온도 변화, 역대 최고 온도를 기록한 시기는?
- 파이썬 데이터 타입
- 클래스 : 로또 
- 예외 처리
- Numpy

- Pandas
- Machine Learning
- Supervised Learning
  - Linear Regression
  - tree
